## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "img/",
  fig.width=6,
  fig.height=4
  )

## ----setup---------------------------------------------------------------
library(PCAgroupVignette)

## ------------------------------------------------------------------------
library(curl)
library(ggplot2)
library(psych)
library(factoextra)

## ------------------------------------------------------------------------
f <- curl("https://raw.githubusercontent.com/benrod86/PCA/master/Froggy_hop_hop.csv")
frogs <- read.csv(f, header = TRUE, sep = ",", stringsAsFactors = TRUE)
head(frogs)

## ------------------------------------------------------------------------
Data=frogs[,1:8]
head(Data)

## ---- echo = FALSE-------------------------------------------------------
pca.frogs3cv <- prcomp (Data, scale = FALSE)
cvplot <- biplot (pca.frogs3cv, cex = c(.1,.7))
title("Covariance Matrix", line=-2)

## ---- echo = FALSE-------------------------------------------------------
pca.frogs2cor <- prcomp (Data, scale = TRUE)
corplot <- biplot (pca.frogs2cor,cex = c(.1, .7))
title("Correlation Matrix", line=-2)

## ------------------------------------------------------------------------
CorDat=cor(Data)
CorDat
pairs(Data, panel=function(x,y){points(x,y); abline(lm(y~x), col='red',lwd=2) }) 

## ------------------------------------------------------------------------
N=dim(Data)[1]
cortest.bartlett(CorDat, n=N)

## ------------------------------------------------------------------------
eigVal=eigen(CorDat)
vectData=eigVal$vectors
eigValv=eigVal$values 
eigValv

## ------------------------------------------------------------------------
plot(c(1:length(eigVal$values)),eigVal$values, type="l", xlab="Principal Components", ylab="Eigenvalues") 
points(c(1:length(eigVal$values)),eigVal$values, pch=19)

## ------------------------------------------------------------------------
library(factoextra)
prt=prcomp(Data, center=TRUE, scale=TRUE)
summary(prt)

## ------------------------------------------------------------------------
fviz_eig(prt, xlab="Principal Components")

## ------------------------------------------------------------------------
scoreData <- prt$x # the values of each sample in terms of the principal components
LoadsData <- prt$rotation  # the relationship between the initial variables and the principal components
LoadsData
barplot(LoadsData[, 1])
barplot(LoadsData[, 2])

## ------------------------------------------------------------------------
#Visualizing PC1 and PC2
biplot(scoreData[,c(1,2)],LoadsData[,c(1,2)], xlabs=rep("*",980), col=c("orange", "black")) # be patient can take some time...

## ------------------------------------------------------------------------
newData <- cbind(scoreData,data.frame(frogs[,9])) # column 9 from our original dataset (h) represents the grouping variable (Risk = Predation Risk) 
colnames(newData) <- c(colnames(newData[1:8]), "Risk")
head(newData)

## ------------------------------------------------------------------------
newData_high <- subset(newData, newData[,9]=="high") 
newData_med <- subset(newData, newData[,9]=="med") 
newData_low <- subset(newData, newData[,9]=="low")
newData_null <- subset(newData, newData[,9]=="null")

## ------------------------------------------------------------------------
lmin <- min(scoreData[,c(1,2)])
lmax <- max(scoreData[,c(1,2)])

plot(scoreData[,c(1,2)], type="n", xlim=c(lmin,lmax), ylim=c(lmin,lmax))
points(newData_high[,1:2], pch=19, col="darkorchid1") 
points(newData_med[,1:2], pch=19, col="aquamarine") 
points(newData_low[,1:2], pch=19, col="khaki1")
points(newData_null[,1:2], pch=19, col="plum2")
arrows(0,0, LoadsData[,1]*9,LoadsData[,2]*9, length = 0.1 ) 
text(LoadsData[,1]*11,LoadsData[,2]*11, labels=rownames(LoadsData))
legend("topleft", legend=c("High Risk", "Medium Risk", "Low Risk", "Null Risk"), col=c("darkorchid1", "aquamarine", "khaki1", "plum2"), pch=16)

## ------------------------------------------------------------------------
lmin=min(scoreData[,c(1,3)])
lmax=max(scoreData[,c(1,3)])
plot(scoreData[,c(1,3)], type="n", xlim=c(lmin,lmax), ylim=c(lmin,lmax))
points(x = newData_high[,1], y = newData_high[, 3], pch=19, col="darkorchid1") 
points(x = newData_med[,1], y = newData_med[, 3], pch=19, col="aquamarine") 
points(x = newData_low[,1], y = newData_low[, 3], pch=19, col="khaki1")
points(x = newData_null[,1], y = newData_null[, 3], pch=19, col="plum2")
arrows(0,0, LoadsData[,1]*8.5,LoadsData[,3]*8.5, length = 0.1 ) 
text(LoadsData[,1]*10.2,LoadsData[,3]*10.2, labels=rownames(LoadsData))
legend("topleft", legend=c("High Risk", "Medium Risk", "Low Risk", "Null Risk"), col=c("darkorchid1", "aquamarine", "khaki1", "plum2"), pch=16)

## ------------------------------------------------------------------------
lmin=min(scoreData[,c(1,4)])
lmax=max(scoreData[,c(1,4)])
plot(scoreData[,c(1,4)], type="n", xlim=c(lmin,lmax), ylim=c(lmin,lmax))
points(x = newData_high[,1], y = newData_high[, 4], pch=19, col="darkorchid1") 
points(x = newData_med[,1], y = newData_med[, 4], pch=19, col="aquamarine") 
points(x = newData_low[,1], y = newData_low[, 4], pch=19, col="khaki1")
points(x = newData_null[,1], y = newData_null[, 4], pch=19, col="plum2")
arrows(0,0, LoadsData[,1]*8.5,LoadsData[,4]*8.5, length = 0.1 ) 
text(LoadsData[,1]*10.2,LoadsData[,4]*10.2, labels=rownames(LoadsData))
legend("topright", legend=c("High Risk", "Medium Risk", "Low Risk", "Null Risk"), col=c("darkorchid1", "aquamarine", "khaki1", "plum2"), pch=16)

## ------------------------------------------------------------------------
h2 <- as.data.frame(prt$x) # Extract the PCA scores for each sample into a new dataframe
h2$Risk <- frogs$Risk # reattach the risk of predaion of each datapoint
head(h2)

## ------------------------------------------------------------------------
h2_pcaplot <- ggplot(data = h2, mapping = aes(x  = PC1, y = PC2, shape = Risk, col = Risk, label= Risk)) +
scale_colour_manual(values = c("darkorchid1", "khaki1", "aquamarine", "plum2")) +
geom_point() + stat_ellipse(geom = "polygon", alpha = .25, aes(fill = Risk), level = 0.95)
h2_pcaplot

## ------------------------------------------------------------------------
h2_pcaplot <- ggplot(data = h2, mapping = aes(x  = PC3, y = PC4, shape = Risk, col = Risk, label= Risk)) +
scale_colour_manual(values = c("darkorchid1", "khaki1", "aquamarine", "plum2")) +
geom_point() + stat_ellipse(geom = "polygon", alpha = .25, aes(fill = Risk), level = 0.95)
h2_pcaplot

## ------------------------------------------------------------------------
f <- curl("https://raw.githubusercontent.com/benrod86/PCA/master/Winchester_Tooth_Data.csv")
teeth <- read.csv(f, header = TRUE, sep = ",", stringsAsFactors = TRUE)
head(teeth)

## ------------------------------------------------------------------------
z.pca <- prcomp(teeth[,3:6], center = TRUE, scale. = TRUE)

## Inspect the results of the PCA
z.pca
summary(z.pca)

## ------------------------------------------------------------------------
fviz_eig(z.pca, xlab="Principal Components")
barplot(z.pca$rotation[, 1])
barplot(z.pca$rotation[, 2])
biplot(z.pca$x[,c(1,2)], z.pca$rotation[,c(1,2)])

## ------------------------------------------------------------------------
z2 <- as.data.frame(z.pca$x) # Extract the PCA scores for each sample into a new dataframe
z2$Species <-  teeth$Species # reattach the species of each datapoint
z2$Diet <- teeth$Diet
head(z2) # Make sure it looks right


## Plot the first two PC scores for each datapoint
pcaplot <- ggplot(data = z2, mapping = aes(x  = PC1, y = PC2, shape = Diet, col = Diet, label= Diet)) +
geom_point() + stat_ellipse(geom = "polygon", alpha = .25, aes(fill = Diet), level = 0.95)
pcaplot

## ------------------------------------------------------------------------
Wyocebus <- cbind(.5, 120, 84, 2.67)
Wyocebus <- as.data.frame(Wyocebus)
Wyocebus <- scale(Wyocebus[1:4], z.pca$center, z.pca$scale) %*% z.pca$rotation 
Wyocebus

## ------------------------------------------------------------------------
Wyocebus <- as.data.frame(Wyocebus)
Wyocebus$Species <- "Wyocebus"
Wyocebus$Diet <- "Wyocebus"
Wyocebus
z3 <- rbind(z2, Wyocebus)
tail(z3)

## ------------------------------------------------------------------------
pcaplot <- ggplot(data = z3, mapping = aes(x  = PC1, y = PC2, shape = Diet, col = Diet, label= Diet)) + geom_point()
pcaplot <- pcaplot + stat_ellipse(geom = "polygon", alpha = .25, aes(fill = Diet), level = 0.95)
pcaplot <- pcaplot + geom_text(data= subset(z3, Diet == "Wyocebus"), aes(label=Diet), hjust= -.1, vjust= .5)
pcaplot

## ------------------------------------------------------------------------
# First calculate the PC scores
New_Fossil <- cbind(.63, 323.5, 42, 4.1)
New_Fossil <- as.data.frame(New_Fossil)
New_Fossil <- scale(New_Fossil[1:4], z.pca$center, z.pca$scale) %*% z.pca$rotation 
New_Fossil

# Second add them to the original dataset of PC scores
New_Fossil <- as.data.frame(New_Fossil)
New_Fossil$Species <- "New_Fossil"
New_Fossil$Diet <- "New_Fossil"
New_Fossil
z3 <- rbind(z2, New_Fossil)
tail(z3)

# Plot everything
pcaplot <- ggplot(data = z3, mapping = aes(x  = PC1, y = PC2, shape = Diet, col = Diet)) + geom_point()
pcaplot <- pcaplot + stat_ellipse(geom = "polygon", alpha = .25, aes(fill = Diet), level = 0.95)
pcaplot <- pcaplot + geom_text(data= subset(z3, Diet == "New_Fossil"), aes(label=Diet), hjust= -.1, vjust= .5)
pcaplot

